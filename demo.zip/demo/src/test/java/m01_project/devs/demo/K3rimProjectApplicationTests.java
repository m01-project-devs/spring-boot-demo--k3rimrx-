package m01_project.devs.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K3rimProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
