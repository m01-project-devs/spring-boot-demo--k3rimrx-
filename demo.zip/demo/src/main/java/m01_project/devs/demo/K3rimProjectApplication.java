package m01_project.devs.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K3rimProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(K3rimProjectApplication.class, args);
	}

}
